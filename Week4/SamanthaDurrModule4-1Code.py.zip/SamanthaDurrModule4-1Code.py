#This import is required because an enumeration is needed to properly create a tree that would
#work. Without this import, there's no method that would allow the AVL or searching algorithms to
#properly work and function.
from enum import Enum, auto
from operator import truediv


#This class is where the balancing factors are located. These are the values placed upon the balanced,
#left or right node heaviness and if one side of each is heavier than the other. These are the definitions
#required for helping the tree balance.
#Additional note to the variables in this class, normal conventions used by me often involve camel casing,
#but snake casing can be used when dealing with variables that aren't easy to camel case. With this being an
#enumeration class, the variable names are cap-locked and thus unable to be camel cased.
class BalanceFactors(Enum):

    # At this spot is when the tree is balanced at the current node.
    BALANCED = 0

    #This is where the tree is left heavy. What this means is that the left subtree has more nodes
    #than the right subtree. The balance has now been skewed.
    LEFT_LEFT = -2

    #This is where the tree is right heavy. That means there are more nodes on the right subtree than on
    #the left subtree.
    RIGHT_RIGHT = 2

    #This is where the left subtree is heavy, but it's not hitting that full skew of being left heavy. What it
    #does means is that the left child node is right heavy.
    LEFT_RIGHT = -1

    #This is where the right subtree is heavy, but not hitting that full skew of a right heavy. What it does
    #mean is that the right child node is left heavy.
    RIGHT_LEFT = 1

#This class defines the logic of a node. This node is what belongs to the AVL tree as a means to
#help determine the heights, the balance, the insertion of a node, and the balance.
class Node:

    #This initializes a new node that contains the given data. The node consists of left and right links,
    #height, and a data element.
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None
        self.height = 1
        self.count = 1

    #This gets the height of a node.
    def getHeight(self) -> int:
        return self.height

    #This calculates and returns the balance fact of the node. This is defined as the difference between
    #the heights of the left and right subtrees. When a node is empty, the tree is considered to be
    #balanced by the definition defined in the BalanceFactors class.
    def balanceFactor(self) -> int:
        leftHeight = 0
        if self.left:
            leftHeight = self.left.getHeight()

        rightHeight = 0
        if self.right:
            rightHeight = self.right.getHeight()
        return leftHeight - rightHeight

    #This checks if the tree is balanced. A tree is considered to be balanced when the difference between
    #the heights of hte left and right subtrees is zero, which is defined in the BalanceFactors class.
    def isBalanced(self) -> bool:
        return self.balanceFactor() == 0

    #This checks the tree at the current level. When it does this, it returns the balance fact of the
    #current node. With this being for an AVL tree, this means that there ends up being five distinct
    #cases that need to be defined. These are what's found in the BalancedFactors class.
    def getBalanceCase(self) -> BalanceFactors:
        factor = self.balanceFactor()
        if factor > 1 and self.left.balanceFactor() >= 0:
            return BalanceFactors.LEFT_LEFT
        elif factor > 1 and self.left.balanceFactor() < 0:
            return BalanceFactors.LEFT_RIGHT
        elif factor < -1 and self.right.balanceFactor() <= 0:
            return BalanceFactors.RIGHT_RIGHT
        elif factor < -1 and self.right.balanceFactor() > 0:
            return BalanceFactors.RIGHT_LEFT
        return BalanceFactors.BALANCED

#This rotates the provided tree node to the right. The rotated tree node that replaces the provided node
#is then returned to the caller.
def rightRotation(treeNode):
    leftChildNode = treeNode.left
    tmp = leftChildNode.right
    leftChildNode.right = treeNode
    treeNode.left = tmp

    #This handles the non cases for the left and right children.
    treeNode.height = max(treeNode.left.getHeight()
           if treeNode.left
           else 0,
                          treeNode.right.getHeight()
                if treeNode.right else 0) + 1
    leftChildNode.height = max(leftChildNode.left.getHeight() if leftChildNode.left else 0,
                                 leftChildNode.right.getHeight() if leftChildNode.right else 0) + 1
    return leftChildNode

#This rotates the provided tree node to the left. The rotated tree noded that replaces the provided node
#is then returned to the caller.
def leftRotation(treeNode):
    rightChildNode = treeNode.right
    tmp = rightChildNode.left
    rightChildNode.left = treeNode
    treeNode.right = tmp
    heightLeft = 0
    heightRight = 0
    if treeNode.left is not None:
        heightLeft = treeNode.left.getHeight()
    if treeNode.right is not None:
        heightRight = treeNode.right.getHeight()
    treeNode.height = max(heightLeft, heightRight) + 1

    heightLeft = 0
    heightRight = 0
    if rightChildNode.left is not None:
        heightLeft = rightChildNode.left.getHeight()
    if rightChildNode.right is not None:
        heightRight = rightChildNode.right.getHeight()
    rightChildNode.height = max(heightLeft, heightRight) + 1
    return rightChildNode

#This is where the insertion happens. This method inserts a new node into the tree and then balances the
#tree if necessary. This is where a check occurs to make sure that the tree is balanced. If it is, then
#nothing needs to be done. That's why it only balances when necessary.
def insertNode(node, data):
    if not node:
        return Node(data)

    if data < node.data:
        node.left = insertNode(node.left, data)
    elif data > node.data:
        node.right = insertNode(node.right, data)
    else:
        node.count += 1
        return node

    #This updates the current node's height to help check if the tree falls within one of the five
    #categories. If the node isn't balanced, then the statements will check the rest and find the proper
    #way to balance the tree.
    node.height = 1 + max(node.left.getHeight() if node.left else 0, node.right.getHeight() if node.right else 0)
    balance_case = node.getBalanceCase()
    if balance_case == BalanceFactors.BALANCED:
        return node
    elif balance_case == BalanceFactors.LEFT_LEFT:
        return rightRotation(node)
    elif balance_case == BalanceFactors.LEFT_RIGHT:
        node.left = leftRotation(node.left)
        return rightRotation(node)
    elif balance_case == BalanceFactors.RIGHT_RIGHT:
        return leftRotation(node)
    elif balance_case == BalanceFactors.RIGHT_LEFT:
        node.right = rightRotation(node.right)
        return leftRotation(node)

#This prints the tree in the sorted order.
def printAVLTree(node, limit = 10, currentCount = 0) -> int:
    if node is None or currentCount >= limit:
        return currentCount

    currentCount = printAVLTree(node.left, limit, currentCount)
    if currentCount >= limit:
        return currentCount

    print(f'word = "{node.data}", count = {node.count}')
    currentCount += 1

    if currentCount >= limit:
        return currentCount

    currentCount = printAVLTree(node.right, limit, currentCount)
    return currentCount


#This reads the datafile and returns the file in an AVL tree.
def readDataFile(filename) -> Node:
    AVLTree = None
    print(f"\n ---File: {filename} (first five words)---")
    with open(filename, "r", encoding = "utf-8-sig") as file:
        lines = file.readlines()
        header = True
        sampleCount = 0
        for line in lines:
            if header:
                header = False
                continue

            line = line.strip()
            if not line:
                continue

            parts = line.split("|")
            word = parts[1].strip()

            AVLTree = insertNode(AVLTree, word)

            if sampleCount < 5:

                print(f'word = "{word}", count = 1')
                sampleCount += 1

    return AVLTree

#This searches the tree for a given word. Since the tree has already been ordered, the data can be searched
#through by walking along the tree and following hte right or left links until the desired node has been found.
#Since the data can contain a number of duplicates, the delete methods will check to see if the count is equal
#to one before removing the node.
def findWord(AVLTree, word) ->bool:
    if AVLTree is None:
        return False
    if AVLTree.data == word:
        return True
    if AVLTree.data > word:
        return findWord(AVLTree.left, word)
    return findWord(AVLTree.right, word)

if __name__ == '__main__':
    root = None
    for ii in range(1,6):
        filename = f"Module 4-1 Data Set-{ii}.csv"
        root = readDataFile(filename)
