import heapq
import time
from typing import Dict, List, Optional, Tuple

#This represents a single node in an explicit binary tree. This is a representation of the min-heap that's
#needed for iteration one.
class HeapNode:

    def __init__(self, sequenceNumber: int, dataText: str):
        self.sequenceNumber = sequenceNumber
        self.dataText = dataText
        self.leftNode: Optional["HeapNode"] = None
        self.rightNode: Optional["HeapNode"] = None

#This is the application to load the pipe-delimited datasets into the min-heap. When that
#is done, this also helps in performing the depth-first search by using two distinct iterations.
class DatasetSearchApplication:

    def __init__(self):
        #This stores the raw tuples into the sequence, word format.
        self.heapData: List[Tuple[int, str]] = []
        self.treeRoot: Optional[HeapNode] = None
        self.recordsLoaded: int = 0

    #This reads a pipe-delimited dataset file, parses the records, and transforms the
    #list into a structured min-heap.
    def LoadDataset(self, filePath: str) -> bool:

        self.heapData = []
        self.treeRoot = None
        self.recordsLoaded = 0

        try:
            with open(filePath, "r", encoding = "utf-8") as fileObject:
                for lineText in fileObject:
                    lineText = lineText.strip()
                    if not lineText or "|" not in lineText:
                        continue
                    partsList = lineText.split("|")
                    if len(partsList) == 2:
                        try:
                            sequenceNumber = int(partsList[0].strip())
                            wordText = partsList[1].strip()
                            self.heapData.append((sequenceNumber, wordText))
                        except ValueError:
                            continue

            #This heapifies the list based on the first element, which is the sequenceNumber.
            heapq.heapify(self.heapData)
            self.recordsLoaded = len(self.heapData)
            self.treeRoot = self.BuildTreeFromHeap(0)
            return True
        except FileNotFoundError:
            print(f"An [ERROR] has been found. The {filePath} file wasn't found.")
            return False

    #This recursively converts the 0-indexed heap array into an explicit HeapNode binary tree object.
    #This is for the DFS traversal.
    def BuildTreeFromHeap(self, indexNumber: int) -> Optional[HeapNode]:
        if indexNumber >= len(self.heapData):
            return None

        sequenceNumber, wordText = self.heapData[indexNumber]
        node = HeapNode(sequenceNumber, wordText)

        #This follows the standard 0-indexed binary heap navigation formulas.
        #This formula is that the left child index = 2 * ii + 1 and the right child index = 2 * ii + 2.
        leftIndex = 2 * indexNumber + 1
        rightIndex = 2 * indexNumber + 2

        node.leftNode = self.BuildTreeFromHeap(leftIndex)
        node.rightNode = self.BuildTreeFromHeap(rightIndex)

        return node

    #This is the first iteration. What this method does is perform a standard pre-order depth-first search
    #over the explicit HeapNode binary tree structure.
    def SearchDfsV1(
            self, targetWord: str
    ) -> Tuple[bool, List[str], int, float]:
        startTime = time.perf_counter()
        recordsSearched = 0
        matchList = []

        if not self.treeRoot:
            return False, matchList, 0, 0.0

        stackList = [self.treeRoot]
        targetLower = targetWord.lower()

        while stackList:
            currentNode = stackList.pop()
            recordsSearched += 1

            if currentNode.dataText.lower() == targetLower:
                matchList.append(currentNode.dataText)

            if currentNode.rightNode:
                stackList.append(currentNode.rightNode)
            if currentNode.leftNode:
                stackList.append(currentNode.leftNode)

        elapsedMilliseconds = (time.perf_counter() - startTime) * 1000
        foundStatus = len(matchList) > 0
        return foundStatus, matchList, recordsSearched, elapsedMilliseconds

    #This is the second iteration that performs an array-based dfs traversal directly over
    #the heap list. This eliminates the pointer overhead.
    def SearchOptimizedV2(
            self, targetWord: str
    ) -> Tuple[bool, List[str], int, float]:
        startTime = time.perf_counter()
        recordsSearched = 0
        matchList = []
        targetLower = targetWord.lower()
        totalRecords = len(self.heapData)

        if totalRecords == 0:
            return False, matchList, 0, 0.0

        #This stack holds the raw integer indices. This is instead of heavy node objects.
        stackList = [0]
        while stackList:
            indexNumber = stackList.pop()
            recordsSearched += 1

            sequenceNumber, wordText = self.heapData[indexNumber]
            if wordText.lower() == targetLower:
                matchList.append(wordText)

            leftIndex = 2 * indexNumber + 1
            rightIndex = 2 * indexNumber + 2

            if rightIndex < totalRecords:
                stackList.append(rightIndex)
            if leftIndex < totalRecords:
                stackList.append(leftIndex)

        elapsedMilliseconds = (time.perf_counter() - startTime) * 1000
        foundStatus = len(matchList) > 0
        return foundStatus, matchList, recordsSearched, elapsedMilliseconds

    def DisplaySearchResults(
            self,
            testLabel: str,
            targetWord: str,
            foundStatus: bool,
            matchList: List[str],
            searchedCount: int,
            elapsedMilliseconds: float,
    ):
        #This formats and prints the standardized test results to the console.
        print("\n" + "=" * 55)
        print(f"TEST CONTEXT: {testLabel}")
        print(f"SEARCH CRITERIA: '{targetWord}'")
        print("-" * 55)

        if foundStatus:
            for matchText in set(matchList):
                print(f"Data Field: {matchText}")
        else:
            print(
                f"Result: The value of '{targetWord}' wasn't found within the dataset."
            )

        print(f"Total Records Searched: {searchedCount}")
        print(f"Execution Time: {elapsedMilliseconds:.4f} ms")
        print("=" * 55 + "\n")


if __name__ == "__main__":
    app = DatasetSearchApplication()

    print("STARTING THE EXPANDED TEST PLAN EXECUTION FOR DATASETS 1-5 (V1 vs. V2)")

    for fileIndex in range(1, 6):
        datasetFile = f"Module 8 Data Set-{fileIndex}.csv"
        print(f"\n[{fileIndex}/5] Processing file: {datasetFile}")

        if app.LoadDataset(datasetFile):
            print(f"Successfully loaded, heapified ({app.recordsLoaded} records), and built binary tree.")

            # Define test targets
            targetExisting = app.heapData[0][1]
            targetAmbiguous = "hello"
            targetGuaranteedAbsent = "wordThatDoesn'tExist"

            # The Existing Term Test

            #Explicit Tree DFS
            foundExV1, matchExV1, countExV1, timeExV1 = app.SearchDfsV1(targetExisting)
            app.DisplaySearchResults(
                f"{datasetFile} (Existing Term Test - V1 Tree DFS)",
                targetExisting,
                foundExV1,
                matchExV1,
                countExV1,
                timeExV1,
            )

            #Array-Index Heap DFS
            foundExV2, matchExV2, countExV2, timeExV2 = app.SearchOptimizedV2(targetExisting)
            app.DisplaySearchResults(
                f"{datasetFile} (Existing Term Test - V2 Array DFS)",
                targetExisting,
                foundExV2,
                matchExV2,
                countExV2,
                timeExV2,
            )

            # The Lexiccal Collision test using 'Hello'

            #Explicit Tree DFS
            foundAmbV1, matchAmbV1, countAmbV1, timeAmbV1 = app.SearchDfsV1(targetAmbiguous)
            app.DisplaySearchResults(
                f"{datasetFile} (Lexical Collision Check: 'hello' - V1 Tree DFS)",
                targetAmbiguous,
                foundAmbV1,
                matchAmbV1,
                countAmbV1,
                timeAmbV1,
            )

            #Array-Index Heap DFS
            foundAmbV2, matchAmbV2, countAmbV2, timeAmbV2 = app.SearchOptimizedV2(targetAmbiguous)
            app.DisplaySearchResults(
                f"{datasetFile} (Lexical Collision Check: 'hello' - V2 Array DFS)",
                targetAmbiguous,
                foundAmbV2,
                matchAmbV2,
                countAmbV2,
                timeAmbV2,
            )

            #The Guaranteed Test with both iterations.

            #Explicit Tree DFS
            foundAbsV1, matchAbsV1, countAbsV1, timeAbsV1 = app.SearchDfsV1(targetGuaranteedAbsent)
            app.DisplaySearchResults(
                f"{datasetFile} (Guaranteed Absent Test - V1 Tree DFS)",
                targetGuaranteedAbsent,
                foundAbsV1,
                matchAbsV1,
                countAbsV1,
                timeAbsV1,
            )

            #Array-Index Heap DFS
            foundAbsV2, matchAbsV2, countAbsV2, timeAbsV2 = app.SearchOptimizedV2(targetGuaranteedAbsent)
            app.DisplaySearchResults(
                f"{datasetFile} (Guaranteed Absent Test - V2 Array DFS)",
                targetGuaranteedAbsent,
                foundAbsV2,
                matchAbsV2,
                countAbsV2,
                timeAbsV2,
            )

        else:
            print(f"[WARNING] The system is skipping {datasetFile}, as the file isn't found in local path.")

    print("\nTHE EXPANDED TEST PLAN EXECUTION IS COMPLETE!")