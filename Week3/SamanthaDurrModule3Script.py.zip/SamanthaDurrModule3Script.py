#The option chosen was the heap sort. The main reason behind this is that the data is a flat, tabular,
#dataset located in five csv files. While binary search would have worked, DFS would have been too intense
#for this sort of data. This is because it's more efficient for O(N Log N) approach from the heap's
#process because it won't choke the memory or cause the CPU to halt. Since this loops through multiple files
#this consideration is important.

#Use of this is to allow for the system to be able to dynamically resize the terminal depending on the
#system. This means that any base set up can get overwritten if text wrapping is needed.
import os
import csv
import heapq
import time
import tracemalloc

#This library is being used for error message displays. This is to reduce the number of print statements
#and keep readability for human readers as opposed to systems. Added advantage to ensuring that anyone
#running can read the issue and not just the technical people.
import textwrap


#This loads the pipe-deliminated records from the csv files while parsing the keys for sorting to return a fully
#sorted list of records that use a min-heap structure.
#The time complexity in this is O(N log N) where N is the number of rows in the csv file.
#As for the space complexity, this is O(N) to store the records list and the heap elements.
def LoadAndSortDatasets (filePath):

    csvRecords = []

    with open(filePath, mode ='r', encoding = 'utf-8') as file:
        csvDatasetReader = csv.DictReader(file, delimiter = '|')
        for row in csvDatasetReader:
            csvRecord = {
                'key': int(row['key']),
                'data_a': row['data-a'],
                'data_b': row['data-b'],
                'validation': row['validation']
            }
            csvRecords.append(csvRecord)

    print(f"The program has loaded {len(csvRecords)} records successfully from the {filePath} file.")

    minHeap = []

    #This pushes each record onto the min-heap. The inclusion of the index helps to prevent comparison
    #errors that can be possible if multiple records share the same 'key' value.
    for csvRecordIndex, csvRecord in enumerate(csvRecords):
        heapq.heappush(minHeap, (csvRecord['key'], csvRecordIndex, csvRecord))

    sortedCsvRecords = []

    #This is the pop component that pops the elements off of the heap in an ascending order. This order is
    #determined by their key.
    while minHeap:
        key, csvRecordIndex, csvRecord = heapq.heappop(minHeap)
        sortedCsvRecords.append(csvRecord)

    return sortedCsvRecords

#This is a loop that works sequentially through the five distinct dataset files that need to be loaded, sorted,
#and also display the preview data.
for DatasetFileIndex in range(1, 6):
    filePath = f"Module 3-1 Activity Data Set-{DatasetFileIndex}.csv"
    try:
        #This starts the memory tracking and performance timer.
        tracemalloc.start()
        startTime = time.perf_counter()

        sortedData = LoadAndSortDatasets(filePath)

        #This stops the performance timer and captures the memory stats.
        endTime = time.perf_counter()
        currentMemory, peakMemory = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        executionTimeMs = (endTime - startTime) * 1000
        peakMemoryKb = peakMemory / 1024

        print(f"Successfully processed Dataset {DatasetFileIndex} ('{filePath}'):")
        print(f"  - Total Records (N): {len(sortedData):,}")
        print(f"  - Execution Time (Time Complexity O(N log N)): {executionTimeMs:.2f} ms")
        print(f"  - Peak Memory Usage (Space Complexity O(N)): {peakMemoryKb:.2f} KB")
        print(f"  - First five sorted records:")
        for r in sortedData[:5]:
            print(f"      Key: {r['key']} | Word A: {r['data_a']} | Word B: {r['data_b']}")
        print("-" * 65)

    except Exception as e:
        errorMessage = (f"An error has occurred while processing dataset {DatasetFileIndex}, '{filePath}'."
                        f"The system has reported the following error: {e}\n"
                        )

        #This allows for determining the width of the terminal, but to safely fetch the terminal width,
        #it has to have a fallback that works when running in a non-interactive environment. While this can
        #appear unnecessary for the current assignment, considering this addition means that if there
        #happens to be any interactive terminal usage that happens through the use of VS Code, Jupyter Notebook
        #or any other IDE, this covers the bases. This is due to being unable to account for every single
        #variable potential of any environment.
        try:
            wrapWidth = min(os.get_terminal_size().columns, 100)
        except (OSError, AttributeError):
            wrapWidth = 80

        print(textwrap.fill(errorMessage, width = wrapWidth))
        print()