#This is the huffman compress and decompression of files. This file is read by raw bytes. This means that any
#text encoding round trips exactly. To expand the compressed file requires the original tree to be used to compress
#the file. This has to be included with the data that's compressed. This is often called the payload. THere's also
#security added to prevent bad actors from causing the decompression function from attempting to expand an invalid
#file. An ID is also used to identify the type.
import heapq
import itertools
import os
import struct
import time
from collections import Counter

#These are the constants.
MAGIC = b"HUF1"
_COUNT_FORMAT = ">H"    #uint16: number of table entries
_ENTRY_FORMAT = ">BQ"   #uint8 symbol + uint64 frequency
_ENTRY_SIZE = struct.calcsize(_ENTRY_FORMAT)

#This class is a node in the huffman tree. The leaves carry a byte value in symbol. The internal nodes carry the
#children. A node is a leaf when it has no children.
class HuffmanNode:

    __slots__ = ("symbol", "left", "right")

    #This creates a leaf, symbol only, or an internal node, children. The byte value for a leaf is 0-255. If there's
    #an internal node, then it outputs none. The left child is reached by a 0 bit and the right child is reached by
    #a 1 bit.
    def __init__(self, symbol = None, left = None, right = None):
        self.symbol = symbol
        self.left = left
        self.right = right

    #This reports whether this node is a leaf. This can return True if the node has no children.

    def is_leaf(self):
        return self.left is None and self.right is None

#This builds a huffman tree from a symbol-frequency table. The ties are broken in this by an insertion counter with
#symbols being inserted in sorted order. This means that the same table always produces the same tree. The decompressor
#relies on this to rebuild the treee the compressor used. If there's only one distinct symbol to exist, the single
#leaf is wrapped in a root with only a left child.
def build_huffman_tree(frequencies):
    if not frequencies:
        return None

    tie_breaker = itertools.count()
    heap = [(freq, next(tie_breaker), HuffmanNode(symbol=sym))
            for sym, freq in sorted(frequencies.items())]
    heapq.heapify(heap)

    if len(heap) == 1:
        return HuffmanNode(left = heap[0][2])

    # Repeatedly merge the two least-frequent subtrees.
    while len(heap) > 1:
        freq_a, _, node_a = heapq.heappop(heap)
        freq_b, _, node_b = heapq.heappop(heap)
        merged = HuffmanNode(left = node_a, right = node_b)
        heapq.heappush(heap, (freq_a + freq_b, next(tie_breaker), merged))

    return heap[0][2]

#This derives the bit code for every symbol in a huffman tree. The root first node is returned by the
#build_huffman_tree function. It can also return none if the table is empty. This walks through the tree iteratively
#build_huffman_tree function. It can also return none if the table is empty. This walks through the tree iteratively
#The left link appends a 0 bit and the right edge appends a 1 bit.
def build_code_table(root):
    codes = {}
    if root is None:
        return codes

    stack = [(root, 0, 0)]  #(node, code bits so far, code length so far)
    while stack:
        node, value, length = stack.pop()
        if node.is_leaf():
            codes[node.symbol] = (value, length)
            continue
        if node.right is not None:
            stack.append((node.right, (value << 1) | 1, length + 1))
        if node.left is not None:
            stack.append((node.left, value << 1, length + 1))
    return codes

#This writes the magic number and frequency table to a binary stream.
def write_header(stream, frequencies):
    stream.write(MAGIC)
    stream.write(struct.pack(_COUNT_FORMAT, len(frequencies)))
    for symbol, freq in sorted(frequencies.items()):
        stream.write(struct.pack(_ENTRY_FORMAT, symbol, freq))

#This reads exactly the specified size bytes from the open binary stream. The binary file object opened for reading
#with the number of bytes required. This then returns the bytes read. There can be a ValueError raised if the
#stream number of bytes read is not equal to the requested size. It can also be raised if the stream is empty.
#This is a security measure to prevent the decompressor from reading an invalid file by reading past the end of it.
def read_bytes(stream, size):
    data = stream.read(size)
    if len(data) != size:
        raise ValueError("The compressed file is truncated or has a corrupted (header).")
    return data

#This reads and validates the header written by the write_header function. The binary file object is positioned
#at the start of the fil. This returns a dictionary mapping byte value to occurrence count. This raises a
#ValueError if the magic number is wrong or the table is malformed.
def read_header(stream):
    if read_bytes(stream, len(MAGIC)) != MAGIC:
        raise ValueError("This is not a Huffman-compressed file (bad magic number).")

    (count,) = struct.unpack(_COUNT_FORMAT,
                             read_bytes(stream, struct.calcsize(_COUNT_FORMAT)))
    if count > 256:
        raise ValueError("Corrupt header: more than 256 symbols.")

    frequencies = {}
    for _ in range(count):
        symbol, freq = struct.unpack(_ENTRY_FORMAT, read_bytes(stream, _ENTRY_SIZE))
        frequencies[symbol] = freq
    return frequencies

#This encodes the raw bytes into a packed huffman bit stream. There are two parameters for this, the original file
#contents, which is the data, and the code table that's built from the _build_code_table. This then returns the
#packed bytes. To that end, the most significant bit is the first with the final byte padded with zero bits. The
#bits are accumulated in an integer and flushed a byte at a time. This is much faster than building a string of 0's and
#1's. This would result in it being 8 times as long. The accumulator is 8 bits wide, which makes the maximum symbol
#value be 255. The accumulator is initialized to 0 and each bit is shifted into the accumulator. There's also MSB
#shifted into the least significant position. The accumulator is then masked to keep only the non-flushed bits and the
#accumulator is reset to 0.
def encode_bytes(data, codes):
    output = bytearray()
    accumulator = 0
    bit_count = 0

    for byte in data:
        value, length = codes[byte]
        accumulator = (accumulator << length) | value
        bit_count += length
        while bit_count >= 8:
            bit_count -= 8
            output.append((accumulator >> bit_count) & 0xFF)
        #This keeps only the unflushed bits.
        accumulator &= (1 << bit_count) - 1

    if bit_count:
        output.append((accumulator << (8 - bit_count)) & 0xFF)

    return bytes(output)

#This is what decodes a packed huffman bit stream back into the raw bytes. The first parameter are the payload, which is
#the packed bit stream produced by encode_bytes. The root is the next parameter that is the root of the huffman that's
#used for encoding. The third parameter is the symbol_count, which is the number of bytes in the original file. This
#all returns the original file contents. What goes deeper is that the decoding stops once the number of bytes
#matches the symbol_count argument. This means that the zero padding at the end of the compressed data gets ignored.
#As for the ValueError, this appears if the compressed data is smaller than the amount of data required. This can
#also appear if an invalid code is encountered. This is a security measure to prevent the decompressor from reading
#past the end of the file if it runs out early or contains an invalid code.
def decode_bytes(payload, root, symbol_count):
    if symbol_count == 0:
        return b""

    output = bytearray()
    node = root

    for byte in payload:
        for shift in range(7, -1, -1):
            node = node.right if (byte >> shift) & 1 else node.left
            if node is None:
                raise ValueError("The compressed data contains an invalid code.")
            if node.is_leaf():
                output.append(node.symbol)
                if len(output) == symbol_count:
                    return bytes(output)
                node = root

    raise ValueError("The compressed file is truncated or has a corrupted (payload).")


#This is the compression file for the huffman algorithm. What this does is compresses a file with the huffman code
#and writes the result to the disk. To make this work, it has to find the file to compress, which is done through
#the use of input_filename. Then there's the output_filename, which is the path for the compressed file. This has
#a default of input_filename + .huf. This returns the path of hte compressed file that has been written. For this
#the steps count byte frequencies, build the tree, derive the codes, and then write the header followed by the
#encoded payload. The header costs 6 + 9*N. N is the distinct bytes that can be at most 256. This can result in the
#very small files coming out larger than the original. Typically, English text shrinks to around 55-60% of its
#original size.
def huffman_compress(input_filename, output_filename = None):
    if output_filename is None:
        output_filename = input_filename + ".huf"

    with open(input_filename, "rb") as source:
        data = source.read()

    frequencies = Counter(data)
    root = build_huffman_tree(frequencies)
    codes = build_code_table(root)
    payload = encode_bytes(data, codes)

    with open(output_filename, "wb") as target:
        write_header(target, frequencies)
        target.write(payload)

    return output_filename

#This decompresses a file that's produced by the huffman_compress function. To accomplish this, it uses the
#ocompressed_filename file, which is a .huf file. This then outputs the restored file. Will default to the compressed
#name with the .huf removed and _decompressed added before the extension. This is to ensure that hte original file
#doesn't get overwritten. To that end, this rebuilds the exact tree the compressor used from the stored frequency
#table that then walks it bit by bit to recover each byte. This raises the ValueError if the file isn't in this
#format or if the file has been corrupted.
def huffman_decompress(compressed_filename, output_filename = None):
    if output_filename is None:
        base = compressed_filename
        if base.endswith(".huf"):
            base = base[:-len(".huf")]
        stem, ext = os.path.splitext(base)
        output_filename = stem + "_decompressed" + ext

    with open(compressed_filename, "rb") as source:
        frequencies = read_header(source)
        payload = source.read()

    root = build_huffman_tree(frequencies)
    data = decode_bytes(payload, root, sum(frequencies.values()))

    with open(output_filename, "wb") as target:
        target.write(data)

    return output_filename


#This is the set of test cases to run.

#This is a sanitation method to blank out the validation column from being printed. While having a row to check is
#important for verifying that the system is capable of reading the data and that nothing has been changed when
#it was decompressed, the validation column is the one that contains the SHA-256 hash. Displaying this in a terminal,
#even for testing purposes, is a security issue that has to be addressed and so this is meant to remove this issue.
def sanitize_sample_row(row_text):
    if "|" not in row_text:
        return row_text
    #This drops only the trailing validation digest while keeping the preceding record fields intact.
    return row_text.rsplit("|", 1)[0]

#This is the first test case, labelled as TC01. This reads the original dataset file in a binary mode
#operation. To verify that it read the file, beyond a time output, is showing a single, non-empty, row from the CSV
#file. If the file is empty, then it reports that hte file is empty instead of printing no sample.
def run_TC01_read_original_dataset(input_filename):
    if not os.path.exists(input_filename):
        print("TC01 | File: " + input_filename + " | Status: Missing file")
        return None

    start_time = time.perf_counter()
    with open(input_filename, "rb") as source:
        data = source.read()
    elapsed_ms = (time.perf_counter() - start_time) * 1000.0

    if len(data) == 0:
        print(
            "TC01 | File: " + input_filename +
            " | Read Time: " + f"{elapsed_ms:.3f} ms" +
            " | Sample Row: the file is empty"
        )
        return data

    decoded_text = data.decode("utf-8", errors = "replace")
    non_empty_rows = [line for line in decoded_text.splitlines() if line.strip()]

    if len(non_empty_rows) == 0:
        sample_row = "The file is empty"
    elif len(non_empty_rows) == 1:
        sample_row = non_empty_rows[0]
    else:
        sample_row = non_empty_rows[1]

    display_row = sanitize_sample_row(sample_row)

    print(
        "TC01 | File: " + input_filename +
        " | Read Time: " + f"{elapsed_ms:.3f} ms" +
        " | Sample Row: " + display_row
    )

    return data

#This is the second test case, called TC02. This checks if the input file is empty, which should result in a skip,
#and then compress the files that are valid through the huffman coding. It times this operation, and reports the
#output file name, compressed size, and whether it's smaller than the original file.
def run_TC02_write_compressed_dataset(input_filename, output_filename):
    if not os.path.exists(input_filename):
        print(
            "TC02 | Input: " + input_filename +
            " | Status: there is a missing input file"
        )
        return None

    original_size = os.path.getsize(input_filename)
    if original_size == 0:
        print(
            "TC02 | Input: " + input_filename +
            " | Status: the file is empty. Skipping compression."
        )
        return None

    start_time = time.perf_counter()
    written_file = huffman_compress(input_filename, output_filename)
    elapsed_ms = (time.perf_counter() - start_time) * 1000.0

    compressed_size = os.path.getsize(written_file)
    if compressed_size < original_size:
        size_comparison = "Smaller than original (" + str(original_size) + " B)"
    elif compressed_size == original_size:
        size_comparison = "Same size as original (" + str(original_size) + " B)"
    else:
        size_comparison = "Larger than original (" + str(original_size) + " B) due to header overhead."

    print(
        "TC02 | File: " + written_file +
        " | Compress Time: " + f"{elapsed_ms:.3f} ms" +
        " | Compressed Size: " + str(compressed_size) + " bytes" +
        " | Comparison: " + size_comparison
    )

    return written_file

#This is the third test case that ensures the program can read the compressed file.
def run_TC03_read_compressed_dataset(compressed_filename):
    if not compressed_filename.endswith(".huf"):
        print(
            "TC03 | File: " + compressed_filename +
            " | Error: This file has the incorrect extension."
        )
        return None

    if not os.path.exists(compressed_filename):
        print(
            "TC03 | File: " + compressed_filename +
            " | Status: the file is missing."
        )
        return None

    start_time = time.perf_counter()
    with open(compressed_filename, "rb") as source:
        frequencies = read_header(source)
        payload = source.read()
    elapsed_ms = (time.perf_counter() - start_time) * 1000.0

    #This builds a short hex/byte sample from the compressed stream.
    sample_bytes = (MAGIC + payload)[:16]
    sample_repr = sample_bytes.hex(" ") if sample_bytes else "There are no compressed payload bytes."

    print(
        "TC03 | File: " + compressed_filename +
        " | Read Time: " + f"{elapsed_ms:.3f} ms" +
        " | Symbols in Tree: " + str(len(frequencies)) +
        " | Sample Data: " + sample_repr
    )

    return frequencies, payload

#This is the fourth test case that decompresses a compressed file.
def run_TC04_decompress_dataset(compressed_filename, output_filename=None):
    if not compressed_filename.endswith(".huf"):
        print(
            "TC04 | Input: " + compressed_filename +
            " | Error: Incorrect compressed file, skipping."
        )
        return None

    if not os.path.exists(compressed_filename):
        print(
            "TC04 | Input: " + compressed_filename +
            " | Status: Missing compressed file, skipping."
        )
        return None

    if output_filename is None:
        base = compressed_filename[:-len(".huf")] if compressed_filename.endswith(".huf") else compressed_filename
        stem, _ = os.path.splitext(base)
        output_filename = stem + ".dec"
    elif not output_filename.endswith(".dec"):
        base, _ = os.path.splitext(output_filename)
        output_filename = base + ".dec"

    start_time = time.perf_counter()
    written_file = huffman_decompress(compressed_filename, output_filename)
    elapsed_ms = (time.perf_counter() - start_time) * 1000.0

    with open(written_file, "rb") as target:
        decompressed_bytes = target.read()

    if len(decompressed_bytes) == 0:
        sample_row = "File is empty"
    else:
        decoded_text = decompressed_bytes.decode("utf-8", errors="replace")
        non_empty_rows = [line for line in decoded_text.splitlines() if line.strip()]
        if len(non_empty_rows) == 0:
            sample_row = "File is empty"
        elif len(non_empty_rows) == 1:
            sample_row = non_empty_rows[0]
        else:
            sample_row = non_empty_rows[1]

    display_row = sanitize_sample_row(sample_row)

    print(
        "TC04 | Output File: " + written_file +
        " | Decompress Time: " + f"{elapsed_ms:.3f} ms" +
        " | Sample Data: " + display_row
    )

    return written_file


#This is the fifth test case that compares the original with the decompressed file.
def run_TC05_compare_files(original_filename, decompressed_filename):
    original_exists = os.path.exists(original_filename)
    decompressed_exists = os.path.exists(decompressed_filename)

    if not original_exists and not decompressed_exists:
        print(
            "TC05 | Comparing: " + original_filename + " and " + decompressed_filename +
            " | Error: Both files are missing (" + original_filename + " and " + decompressed_filename + ")."
        )
        return None

    if not original_exists:
        print(
            "TC05 | Comparing: " + original_filename + " and " + decompressed_filename +
            " | Error: Original file is missing (" + original_filename + ")."
        )
        return None

    if not decompressed_exists:
        print(
            "TC05 | Comparing: " + original_filename + " and " + decompressed_filename +
            " | Error: Decompressed file is missing (" + decompressed_filename + ")."
        )
        return None

    with open(original_filename, "rb") as f1:
        data1 = f1.read()
    with open(decompressed_filename, "rb") as f2:
        data2 = f2.read()

    if data1 == data2:
        print(
            "TC05 | Comparing: " + original_filename + " and " + decompressed_filename +
            " | Success: the files are identical"
        )
        return True
    else:
        print(
            "TC05 | Comparing: " + original_filename + " and " + decompressed_filename +
            " | Error: the files are different."
        )
        return False

#This is the entry point for the application.
if __name__ == "__main__":
    import sys

    #This is a text case that compresses each input file, decompresses it, and compares the decompressed
    #file against the original to ensure that the file is identical to each input file. The success of this should
    #show that each input file matches each decompressed file. The failure is that one or more input files don't
    #match their equivalent output files.

    input_files = [
                    "CS 680 Project Data Set-1.csv",
                    "CS 680 Project Data Set-2.csv",
                    "CS 680 Project Data Set-3.csv",
                    "CS 680 Project Data Set-4.csv"
                   ]

    output_files = ["CS 680 Project Data Set-1.csv.huf",
                   "CS 680 Project Data Set-2.csv.huf",
                   "CS 680 Project Data Set-3.csv.huf",
                   "CS 680 Project Data Set-4.csv.huf"
                   ]

    decompressed_files = [
                   "CS 680 Project Data Set-1.csv.dec",
                   "CS 680 Project Data Set-2.csv.dec",
                   "CS 680 Project Data Set-3.csv.dec",
                   "CS 680 Project Data Set-4.csv.dec"
                   ]

    #This is for the first test case to run.
    for ii in range(len(input_files)):
        run_TC01_read_original_dataset(input_files[ii])

    empty_test_file = "tc_01_empty_test.csv"
    with open(empty_test_file, "wb") as empty_file:
        pass

    try:
        run_TC01_read_original_dataset(empty_test_file)
    finally:
        if os.path.exists(empty_test_file):
            os.remove(empty_test_file)

    #This is for the second test case.
    for ii in range(len(input_files)):
        input_file = input_files[ii]
        output_file = output_files[ii]
        run_TC02_write_compressed_dataset(input_file, output_file)

    empty_compress_file = "tc_02_empty_test.csv"
    empty_compress_out = "tc_02_empty_test.csv.huf"
    with open(empty_compress_file, "wb") as empty_file:
        pass

    try:
        run_TC02_write_compressed_dataset(empty_compress_file, empty_compress_out)
    finally:
        for temp_path in (empty_compress_file, empty_compress_out):
            if os.path.exists(temp_path):
                os.remove(temp_path)

    #This is the third test case.
    for ii in range(len(output_files)):
        run_TC03_read_compressed_dataset(output_files[ii])

    #This is the edge case for TC03.
    run_TC03_read_compressed_dataset("invalid_extension.txt")

    for ii in range(len(output_files)):
        output_file = output_files[ii]
        decompressed_file = decompressed_files[ii]
        print("Decompressing: " + output_file)
        huffman_decompress(output_file, decompressed_file)

    #This is the fourth test case.
    for ii in range(len(output_files)):
        run_TC04_decompress_dataset(output_files[ii], decompressed_files[ii])

    #This is the edge case for TC04.
    run_TC04_decompress_dataset("wrong_format.bin", "wrong_format.dec")

    for ii in range(len(input_files)):
        run_TC05_compare_files(input_files[ii], decompressed_files[ii])

    #This tests the edge cases for TC05.
    run_TC05_compare_files(input_files[0], "nonexistent_file.dec")